# recognize-digits
Modification of https://www.pyimagesearch.com/2017/02/13/recognizing-digits-with-opencv-and-python/
. Hi this is just a fork from great blog post from Adrian above.
I tried to use Adrian's code as a base to recognize digits from my calculator. 
All the modifications I made allow me to recognize digits shown on my calculator. 
Even after modification my code is still be able to recognize digits from Adrians's example image.
